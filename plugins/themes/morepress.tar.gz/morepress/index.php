<?php


require_once('MorePressThemePlugin.inc.php');

return new MorePressThemePlugin();

?>
